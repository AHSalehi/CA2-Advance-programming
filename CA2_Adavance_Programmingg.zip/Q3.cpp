#include <iostream>
#include <vector>
using namespace std;
typedef vector<vector<int>> map;
// solving sudoko using permutation
// in this method(Created by myself) we  use backtracking and recursion
// * : a star assigned to scope     _0_ ___ ___ _3_ ___ ___ _6_ ___ ___
//                                0|_*_|___|___|_*_|___|___|_*_|___|___|
//                                 |___|___|___|___|___|___|___|___|___|
//                                 |___|___|___|___|___|___|___|___|___|
//                                3|_*_|___|___|_*_|___|___|_*_|___|___|
//                                 |___|___|___|___|___|___|___|___|___|
//                                 |___|___|___|___|___|___|___|___|___|
//				                  6|_*_|___|___|_*_|___|___|_*_|___|___|
//                                 |___|___|___|___|___|___|___|___|___|
//                                 |___|___|___|___|___|___|___|___|___|
//
// starRow = row_cell - (row_cell % 3)      <---0,1,2--->  : sign for loops
// starCol = col_cell - (col_cell % 3)      <---0,1,2--->  : sign for loops 
// step #1 : build a function to print map of sudoku
#define SIZE 9
void print_map(map& grid){
    for(auto& list : grid){
        for(auto& item : list){
            cout<<item<<" ";
        }
        cout<<endl;
    }
}
// step #2 : build a function to find repetition of character in single row , col , scope
bool find_in_row(map& grid, int row, int item){
    for(auto& thing : grid[row]){
        if(item == thing)
            return true; // item is founded in row
    }
    return false;
}
bool find_in_col(map& grid, int col, int item){
    for(auto& thing : grid){
        if(item == thing[col])
            return true; // item is founded in col
    }
    return false;
}
bool find_in_scope(map& grid, int row, int col, int item){ // scope is 
    row = row - (row % 3); col = col - (col % 3);
    for(auto& i : {0, 1, 2}){
        for(auto& j : {0, 1, 2}){
            if(grid[row + i][col + j] == item)
                return true; // item is founded in scope
        }
    }
    return false;
} // end of validators
// step #3 : solving function
bool solve_sudoku(map& grid, int row, int col){
    if(row == SIZE - 1 && col == SIZE) //  condition of ending
        return true;
    if(col == SIZE){ // end of row of map ----> go to next line (row) and check from col = 0
        row++;
        col = 0;
    }
    if(grid[row][col] != 0){
        return solve_sudoku(grid, row, col+1); // if the cell has already filled, go to next cell of the row
    }
    for(int number = 1;number <= 9;number++){
        if(find_in_row(grid, row,number) == false && find_in_col(grid, col, number) == false && find_in_scope(grid, row, col, number) == false){
            grid[row][col] = number; // then check for next cell and next assumption
            if(solve_sudoku(grid, row, col + 1))
                return true;
        }
        grid[row][col] = 0; // then backtrack to first state of cell becuase all assumptions was wrong
    }
    return false;
}//
// step #4 : get map from user I/O
map get_map(){
    map arr;
    int data;
    for(int i = 0; i < SIZE;i++){
        arr.push_back({});
        for(int j = 0; j < SIZE;j++){
            cin>>data;
            arr[i].push_back(data);
        }
    }
    return arr;
}
int main(){
    map grid = get_map();
    if(solve_sudoku(grid, 0 , 0)){
        cout<<"\n\n";
        print_map(grid);
    }
    else
        cout<<-1<<endl; // If the map were unsolveable , print -1 
}