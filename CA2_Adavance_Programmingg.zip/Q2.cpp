#include <iostream>
#include <vector>
using namespace std;
// testing codes
/*void print_vector(vector<char>& arr){
    cout<<"This array : "<<endl;
    for(auto& item : arr){
        cout<<item<<' -- ';
    }
    cout<<endl;
}*/
void swap_in_string(string& s, int i,int j){
    char temp = s[i];
    s[i] = s[j];
    s[j] = temp;
}
string swap_special(string s,int left, int right){
    if(right <= left){
        return s;
    }
    else{
        swap_in_string(s, left, right);
        // cout << " swaped string  : "<<s<<endl; //  * test code
        return swap_special(s, left + 2, right-1);
    }
}
int main(){
    string s;cin >> s;
    int left,right;
    left = 0;
    right = s.length() - 1;
    cout << swap_special(s, left, right)<<endl;
}