#include <iostream>
#include <string>
using namespace std;
float power_i3(int gen){ // f_pwr :: power of first generation of core_i3 cpu
    if(gen == 1){
        return 1;
    }
    else{
        return 1.5*power_i3(gen - 1);
    }
}
float power_i5(int gen){
    if(gen == 1){
        return 1.4;
    }
    else{
        return ((1.2*power_i5(gen - 1)) + (0.2 * power_i3(gen)));
    }
}
float power_i7(int gen){
    if(gen == 1){
        return 1.7;
    }
    else{
        return ((1.3 * power_i7(gen - 1)) +(0.3 * power_i5(gen)) + (0.2 * power_i3(gen)));
    }
}
int main(){
    int year; cin >> year;
    int generation;
    char cpu[] = {'3', '5', '7'};
    string out = "core i";
    if(year % 3 == 0){
        out += cpu[2];
        generation = year / 3;
        cout<<out<<endl<<power_i7(generation)<<endl;
    }
    else{
        out += cpu[(year % 3) - 1];
        generation = (year / 3) + 1;
        switch (cpu[(year % 3) - 1])
        {
        case '3':
            cout<<out<<endl<<power_i3(generation)<<endl;
            break;
        case '5':
            cout<<out<<endl<<power_i5(generation)<<endl;
            break;
        }
    }
}